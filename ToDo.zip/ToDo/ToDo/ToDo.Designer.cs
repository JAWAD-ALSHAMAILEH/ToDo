﻿
using System.Windows.Forms;

namespace ToDo
{
    partial class ToDo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ToDo));
            this.btnİcons = new System.Windows.Forms.ImageList(this.components);
            this.contentPanel = new System.Windows.Forms.Panel();
            this.allFormList = new System.Windows.Forms.Button();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.welcomePic = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnMinimize = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.menuPanel = new System.Windows.Forms.Panel();
            this.todoBaslik = new System.Windows.Forms.Label();
            this.todoPic = new System.Windows.Forms.PictureBox();
            this.contentPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.welcomePic)).BeginInit();
            this.panel1.SuspendLayout();
            this.menuPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.todoPic)).BeginInit();
            this.SuspendLayout();
            // 
            // btnİcons
            // 
            this.btnİcons.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("btnİcons.ImageStream")));
            this.btnİcons.TransparentColor = System.Drawing.Color.Transparent;
            this.btnİcons.Images.SetKeyName(0, "cancel.png");
            this.btnİcons.Images.SetKeyName(1, "info.png");
            this.btnİcons.Images.SetKeyName(2, "minimize.png");
            // 
            // contentPanel
            // 
            this.contentPanel.Controls.Add(this.allFormList);
            this.contentPanel.Controls.Add(this.checkBox1);
            this.contentPanel.Controls.Add(this.welcomePic);
            this.contentPanel.Location = new System.Drawing.Point(299, 49);
            this.contentPanel.Margin = new System.Windows.Forms.Padding(4);
            this.contentPanel.Name = "contentPanel";
            this.contentPanel.Size = new System.Drawing.Size(1603, 882);
            this.contentPanel.TabIndex = 3;
            // 
            // allFormList
            // 
            this.allFormList.BackColor = System.Drawing.Color.Transparent;
            this.allFormList.BackgroundImage = global::ToDo.Properties.Resources.btn;
            this.allFormList.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.allFormList.Cursor = System.Windows.Forms.Cursors.Hand;
            this.allFormList.FlatAppearance.BorderSize = 0;
            this.allFormList.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.allFormList.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.allFormList.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.allFormList.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.75F);
            this.allFormList.ForeColor = System.Drawing.Color.White;
            this.allFormList.ImageList = this.btnİcons;
            this.allFormList.Location = new System.Drawing.Point(611, 674);
            this.allFormList.Margin = new System.Windows.Forms.Padding(4);
            this.allFormList.Name = "allFormList";
            this.allFormList.Size = new System.Drawing.Size(400, 92);
            this.allFormList.TabIndex = 5;
            this.allFormList.Text = "START";
            this.allFormList.UseVisualStyleBackColor = false;
            this.allFormList.Click += new System.EventHandler(this.allFormList_Click);
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox1.Location = new System.Drawing.Point(679, 631);
            this.checkBox1.Margin = new System.Windows.Forms.Padding(4);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(270, 35);
            this.checkBox1.TabIndex = 3;
            this.checkBox1.Text = "Let\'s start planning \r\n";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // welcomePic
            // 
            this.welcomePic.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.welcomePic.Image = global::ToDo.Properties.Resources.welcome;
            this.welcomePic.Location = new System.Drawing.Point(630, 404);
            this.welcomePic.Margin = new System.Windows.Forms.Padding(4);
            this.welcomePic.Name = "welcomePic";
            this.welcomePic.Size = new System.Drawing.Size(347, 201);
            this.welcomePic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.welcomePic.TabIndex = 1;
            this.welcomePic.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.BackgroundImage = global::ToDo.Properties.Resources.btngra;
            this.panel1.Controls.Add(this.btnMinimize);
            this.panel1.Controls.Add(this.btnClose);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1901, 49);
            this.panel1.TabIndex = 2;
            this.panel1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseDown);
            this.panel1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseMove);
            this.panel1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseUp);
            // 
            // btnMinimize
            // 
            this.btnMinimize.BackColor = System.Drawing.Color.Transparent;
            this.btnMinimize.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMinimize.FlatAppearance.BorderSize = 0;
            this.btnMinimize.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnMinimize.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnMinimize.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMinimize.ForeColor = System.Drawing.Color.Transparent;
            this.btnMinimize.ImageKey = "minimize.png";
            this.btnMinimize.ImageList = this.btnİcons;
            this.btnMinimize.Location = new System.Drawing.Point(1785, 2);
            this.btnMinimize.Margin = new System.Windows.Forms.Padding(4);
            this.btnMinimize.Name = "btnMinimize";
            this.btnMinimize.Size = new System.Drawing.Size(52, 43);
            this.btnMinimize.TabIndex = 4;
            this.btnMinimize.UseVisualStyleBackColor = false;
            this.btnMinimize.Click += new System.EventHandler(this.btnMinimize_Click);
            // 
            // btnClose
            // 
            this.btnClose.BackColor = System.Drawing.Color.Transparent;
            this.btnClose.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnClose.FlatAppearance.BorderSize = 0;
            this.btnClose.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnClose.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClose.ForeColor = System.Drawing.Color.Transparent;
            this.btnClose.ImageKey = "cancel.png";
            this.btnClose.ImageList = this.btnİcons;
            this.btnClose.Location = new System.Drawing.Point(1845, 2);
            this.btnClose.Margin = new System.Windows.Forms.Padding(4);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(52, 43);
            this.btnClose.TabIndex = 3;
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // menuPanel
            // 
            this.menuPanel.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.menuPanel.BackgroundImage = global::ToDo.Properties.Resources.btngra;
            this.menuPanel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.menuPanel.Controls.Add(this.todoBaslik);
            this.menuPanel.Controls.Add(this.todoPic);
            this.menuPanel.Location = new System.Drawing.Point(0, 0);
            this.menuPanel.Margin = new System.Windows.Forms.Padding(4);
            this.menuPanel.Name = "menuPanel";
            this.menuPanel.Size = new System.Drawing.Size(299, 944);
            this.menuPanel.TabIndex = 0;
            // 
            // todoBaslik
            // 
            this.todoBaslik.AutoSize = true;
            this.todoBaslik.BackColor = System.Drawing.Color.Transparent;
            this.todoBaslik.Font = new System.Drawing.Font("Segoe UI", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.todoBaslik.Location = new System.Drawing.Point(45, 510);
            this.todoBaslik.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.todoBaslik.Name = "todoBaslik";
            this.todoBaslik.Size = new System.Drawing.Size(195, 45);
            this.todoBaslik.TabIndex = 1;
            this.todoBaslik.Text = "TO DO LIST";
            this.todoBaslik.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // todoPic
            // 
            this.todoPic.BackColor = System.Drawing.Color.Transparent;
            this.todoPic.Image = ((System.Drawing.Image)(resources.GetObject("todoPic.Image")));
            this.todoPic.Location = new System.Drawing.Point(32, 312);
            this.todoPic.Margin = new System.Windows.Forms.Padding(4);
            this.todoPic.Name = "todoPic";
            this.todoPic.Size = new System.Drawing.Size(203, 194);
            this.todoPic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.todoPic.TabIndex = 1;
            this.todoPic.TabStop = false;
            // 
            // ToDo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1900, 933);
            this.Controls.Add(this.contentPanel);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.menuPanel);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "ToDo";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "To Do";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.ToDo_Load);
            this.contentPanel.ResumeLayout(false);
            this.contentPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.welcomePic)).EndInit();
            this.panel1.ResumeLayout(false);
            this.menuPanel.ResumeLayout(false);
            this.menuPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.todoPic)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel menuPanel;
        private System.Windows.Forms.PictureBox todoPic;
        private System.Windows.Forms.Label todoBaslik;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnMinimize;
        private System.Windows.Forms.ImageList btnİcons;
        private System.Windows.Forms.PictureBox welcomePic;
        private System.Windows.Forms.Panel contentPanel;
        private System.Windows.Forms.Button allFormList;
        private System.Windows.Forms.CheckBox checkBox1;
    }
}

