﻿using System;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace ToDo
{
    public partial class ToDo : Form
    {
        // استيراد دالة من مكتبة Gdi32.dll لإنشاء حواف مستديرة للنموذج
        [DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]
        private static extern IntPtr CreateRoundRectRgn
        (
            int nLeftRect,
            int nTopRect,
            int nRightRect,
            int nBottomRect,
            int nWidthEllipse,
            int nHeightEllipse
        );

        // متغيرات لتتبع حالة الضغط على الفأرة وموقعها الأخير
        private bool mouseDown;
        private Point lastLocation;

        public ToDo()
        {
            InitializeComponent();
            // تعيين حواف مستديرة للنموذج عند التحميل
            Region = System.Drawing.Region.FromHrgn(CreateRoundRectRgn(0, 0, Width, Height, 20, 20));
        }

        // ==========================================
        // أحداث تحريك النموذج
        // ==========================================

        // حدث عند الضغط على الفأرة داخل الـ Panel
        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            mouseDown = true;  // تم الضغط على الفأرة
            lastLocation = e.Location;  // حفظ الموقع الأخير للفأرة
        }

        // حدث عند تحريك الفأرة داخل الـ Panel
        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            if (mouseDown)
            {
                // تحريك النموذج بناءً على حركة الفأرة
                this.Location = new Point(
                    (this.Location.X - lastLocation.X) + e.X, 
                    (this.Location.Y - lastLocation.Y) + e.Y);

                this.Update();  // تحديث النموذج
            }
        }

        // حدث عند رفع الضغط عن الفأرة
        private void panel1_MouseUp(object sender, MouseEventArgs e)
        {
            mouseDown = false;  // تم رفع الضغط عن الفأرة
        }

        // ==========================================
        // أحداث الأزرار
        // ==========================================

        // حدث النقر على زر الإغلاق
        private void btnClose_Click(object sender, EventArgs e)
        {
            Application.Exit();  // إغلاق التطبيق
        }

        // حدث النقر على زر التصغير
        private void btnMinimize_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;  // تصغير النموذج
        }

        // ==========================================
        // أحداث التحكم في الواجهة
        // ==========================================

        // حدث النقر على زر عرض النموذج الرئيسي
        private void allFormList_Click(object sender, EventArgs e)
        {
            contentPanel.Controls.Clear();  // مسح محتوى الـ Panel

            // إنشاء نموذج allForm وإضافته إلى الـ Panel
            allForm allForm = new allForm();
            allForm.TopLevel = false;
            contentPanel.Controls.Add(allForm);

            // عرض النموذج وتوسيعه لملء الـ Panel
            allForm.Show();
            allForm.Dock = DockStyle.Fill;
            allForm.BringToFront();

            allFormList.Visible = false;  // إخفاء الزر بعد النقر
        }

        // حدث تغيير حالة CheckBox
        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            // تفعيل أو تعطيل الزر بناءً على حالة الـ CheckBox
            if (checkBox1.Checked)
            {
                allFormList.Enabled = true;
            }
            else
            {
                allFormList.Enabled = false;
            }
        }

        // ==========================================
        // أحداث التحميل
        // ==========================================

        // حدث تحميل النموذج
        private void ToDo_Load(object sender, EventArgs e)
        {
            allFormList.Enabled = false;  // تعطيل الزر عند التحميل
        }
    }
}