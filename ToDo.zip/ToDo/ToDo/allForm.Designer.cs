﻿
using System;
using System.Windows.Forms;

namespace ToDo
{
    partial class allForm
    {
       
        private System.ComponentModel.IContainer components = null;

        /// name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

         
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(allForm));
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.lblDate = new System.Windows.Forms.Label();
            this.monthCalendar1 = new System.Windows.Forms.MonthCalendar();
            this.label3 = new System.Windows.Forms.Label();
            this.txtTaskDescription = new System.Windows.Forms.TextBox();
            this.lblSelectDate = new System.Windows.Forms.Label();
            this.calendarList = new System.Windows.Forms.ListBox();
            this.btnAddToCalendar = new System.Windows.Forms.Button();
            this.ımageList1 = new System.Windows.Forms.ImageList(this.components);
            this.btnRemoveFromCalendar = new System.Windows.Forms.Button();
            this.txtTaskInput = new System.Windows.Forms.TextBox();
            this.btnMarkCompleted = new System.Windows.Forms.Button();
            this.listCompletedTasks = new System.Windows.Forms.ListBox();
            this.listPendingTasks = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.btnAddTask = new System.Windows.Forms.Button();
            this.btnDeleteTask = new System.Windows.Forms.Button();
            this.btnUndoCompleted = new System.Windows.Forms.Button();
            this.lblCountdown = new System.Windows.Forms.Label();
            this.btnPauseTimer = new System.Windows.Forms.Button();
            this.btnStartTimer = new System.Windows.Forms.Button();
            this.txtTimerInput = new System.Windows.Forms.TextBox();
            this.chkSeconds = new System.Windows.Forms.CheckBox();
            this.chkMinutes = new System.Windows.Forms.CheckBox();
            this.chkHours = new System.Windows.Forms.CheckBox();
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.btnResetTimer = new System.Windows.Forms.Button();
            this.btnResumeTimer = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.btnGenerateReport = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // lblDate
            // 
            this.lblDate.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblDate.AutoSize = true;
            this.lblDate.Font = new System.Drawing.Font("Microsoft Tai Le", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDate.Location = new System.Drawing.Point(22, 65);
            this.lblDate.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(287, 39);
            this.lblDate.TabIndex = 19;
            this.lblDate.Text = "Time and date now";
            this.lblDate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // monthCalendar1
            // 
            this.monthCalendar1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.monthCalendar1.FirstDayOfWeek = System.Windows.Forms.Day.Sunday;
            this.monthCalendar1.Location = new System.Drawing.Point(451, 30);
            this.monthCalendar1.Margin = new System.Windows.Forms.Padding(12, 11, 12, 11);
            this.monthCalendar1.Name = "monthCalendar1";
            this.monthCalendar1.ShowWeekNumbers = true;
            this.monthCalendar1.TabIndex = 18;
            this.monthCalendar1.DateChanged += new System.Windows.Forms.DateRangeEventHandler(this.monthCalendar1_DateChanged);
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.Location = new System.Drawing.Point(16, 252);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(145, 20);
            this.label3.TabIndex = 23;
            this.label3.Text = "Task To Be Done:";
            // 
            // txtTaskDescription
            // 
            this.txtTaskDescription.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtTaskDescription.Font = new System.Drawing.Font("Microsoft Tai Le", 14.25F);
            this.txtTaskDescription.Location = new System.Drawing.Point(169, 252);
            this.txtTaskDescription.Margin = new System.Windows.Forms.Padding(4);
            this.txtTaskDescription.Multiline = true;
            this.txtTaskDescription.Name = "txtTaskDescription";
            this.txtTaskDescription.Size = new System.Drawing.Size(226, 101);
            this.txtTaskDescription.TabIndex = 22;
            // 
            // lblSelectDate
            // 
            this.lblSelectDate.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblSelectDate.AutoSize = true;
            this.lblSelectDate.Font = new System.Drawing.Font("Microsoft Tai Le", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSelectDate.Location = new System.Drawing.Point(23, 113);
            this.lblSelectDate.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSelectDate.Name = "lblSelectDate";
            this.lblSelectDate.Size = new System.Drawing.Size(175, 39);
            this.lblSelectDate.TabIndex = 21;
            this.lblSelectDate.Text = "Select Date";
            this.lblSelectDate.Click += new System.EventHandler(this.lblSelectDate_Click);
            // 
            // calendarList
            // 
            this.calendarList.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.calendarList.Font = new System.Drawing.Font("Microsoft Tai Le", 14.25F);
            this.calendarList.FormattingEnabled = true;
            this.calendarList.HorizontalScrollbar = true;
            this.calendarList.ItemHeight = 30;
            this.calendarList.Location = new System.Drawing.Point(417, 252);
            this.calendarList.Margin = new System.Windows.Forms.Padding(4);
            this.calendarList.Name = "calendarList";
            this.calendarList.Size = new System.Drawing.Size(333, 154);
            this.calendarList.TabIndex = 26;
            // 
            // btnAddToCalendar
            // 
            this.btnAddToCalendar.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnAddToCalendar.BackColor = System.Drawing.Color.Transparent;
            this.btnAddToCalendar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAddToCalendar.FlatAppearance.BorderSize = 0;
            this.btnAddToCalendar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnAddToCalendar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnAddToCalendar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAddToCalendar.Font = new System.Drawing.Font("Microsoft Tai Le", 14.25F);
            this.btnAddToCalendar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAddToCalendar.ImageKey = "plus.png";
            this.btnAddToCalendar.ImageList = this.ımageList1;
            this.btnAddToCalendar.Location = new System.Drawing.Point(142, 357);
            this.btnAddToCalendar.Margin = new System.Windows.Forms.Padding(4);
            this.btnAddToCalendar.Name = "btnAddToCalendar";
            this.btnAddToCalendar.Size = new System.Drawing.Size(187, 49);
            this.btnAddToCalendar.TabIndex = 25;
            this.btnAddToCalendar.Text = "Add Task";
            this.btnAddToCalendar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnAddToCalendar.UseVisualStyleBackColor = false;
            this.btnAddToCalendar.Click += new System.EventHandler(this.btnAddToCalendar_Click);
            // 
            // ımageList1
            // 
            this.ımageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ımageList1.ImageStream")));
            this.ımageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.ımageList1.Images.SetKeyName(0, "check.png");
            this.ımageList1.Images.SetKeyName(1, "cancel.png");
            this.ımageList1.Images.SetKeyName(2, "back-arrow.png");
            this.ımageList1.Images.SetKeyName(3, "plus.png");
            this.ımageList1.Images.SetKeyName(4, "report.png");
            // 
            // btnRemoveFromCalendar
            // 
            this.btnRemoveFromCalendar.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnRemoveFromCalendar.BackColor = System.Drawing.Color.Transparent;
            this.btnRemoveFromCalendar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRemoveFromCalendar.FlatAppearance.BorderSize = 0;
            this.btnRemoveFromCalendar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnRemoveFromCalendar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnRemoveFromCalendar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRemoveFromCalendar.Font = new System.Drawing.Font("Microsoft Tai Le", 14.25F);
            this.btnRemoveFromCalendar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnRemoveFromCalendar.ImageKey = "cancel.png";
            this.btnRemoveFromCalendar.ImageList = this.ımageList1;
            this.btnRemoveFromCalendar.Location = new System.Drawing.Point(142, 407);
            this.btnRemoveFromCalendar.Margin = new System.Windows.Forms.Padding(4);
            this.btnRemoveFromCalendar.Name = "btnRemoveFromCalendar";
            this.btnRemoveFromCalendar.Size = new System.Drawing.Size(213, 48);
            this.btnRemoveFromCalendar.TabIndex = 24;
            this.btnRemoveFromCalendar.Text = "Delete Task";
            this.btnRemoveFromCalendar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnRemoveFromCalendar.UseVisualStyleBackColor = false;
            this.btnRemoveFromCalendar.Click += new System.EventHandler(this.btnRemoveFromCalendar_Click);
            // 
            // txtTaskInput
            // 
            this.txtTaskInput.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtTaskInput.Font = new System.Drawing.Font("Microsoft Tai Le", 14.25F);
            this.txtTaskInput.Location = new System.Drawing.Point(23, 219);
            this.txtTaskInput.Margin = new System.Windows.Forms.Padding(4);
            this.txtTaskInput.Multiline = true;
            this.txtTaskInput.Name = "txtTaskInput";
            this.txtTaskInput.Size = new System.Drawing.Size(231, 102);
            this.txtTaskInput.TabIndex = 31;
            // 
            // btnMarkCompleted
            // 
            this.btnMarkCompleted.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnMarkCompleted.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMarkCompleted.FlatAppearance.BorderSize = 0;
            this.btnMarkCompleted.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnMarkCompleted.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnMarkCompleted.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMarkCompleted.Font = new System.Drawing.Font("Microsoft Tai Le", 14.25F);
            this.btnMarkCompleted.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnMarkCompleted.ImageKey = "check.png";
            this.btnMarkCompleted.ImageList = this.ımageList1;
            this.btnMarkCompleted.Location = new System.Drawing.Point(262, 454);
            this.btnMarkCompleted.Margin = new System.Windows.Forms.Padding(4);
            this.btnMarkCompleted.Name = "btnMarkCompleted";
            this.btnMarkCompleted.Size = new System.Drawing.Size(221, 50);
            this.btnMarkCompleted.TabIndex = 29;
            this.btnMarkCompleted.Text = "completed";
            this.btnMarkCompleted.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnMarkCompleted.UseVisualStyleBackColor = true;
            this.btnMarkCompleted.Click += new System.EventHandler(this.btnMarkCompleted_Click);
            // 
            // listCompletedTasks
            // 
            this.listCompletedTasks.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.listCompletedTasks.Font = new System.Drawing.Font("Microsoft Tai Le", 14.25F);
            this.listCompletedTasks.FormattingEnabled = true;
            this.listCompletedTasks.ItemHeight = 30;
            this.listCompletedTasks.Location = new System.Drawing.Point(487, 127);
            this.listCompletedTasks.Margin = new System.Windows.Forms.Padding(4);
            this.listCompletedTasks.Name = "listCompletedTasks";
            this.listCompletedTasks.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple;
            this.listCompletedTasks.Size = new System.Drawing.Size(217, 304);
            this.listCompletedTasks.TabIndex = 28;
            // 
            // listPendingTasks
            // 
            this.listPendingTasks.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.listPendingTasks.Font = new System.Drawing.Font("Microsoft Tai Le", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listPendingTasks.FormattingEnabled = true;
            this.listPendingTasks.ItemHeight = 30;
            this.listPendingTasks.Location = new System.Drawing.Point(262, 127);
            this.listPendingTasks.Margin = new System.Windows.Forms.Padding(4);
            this.listPendingTasks.Name = "listPendingTasks";
            this.listPendingTasks.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple;
            this.listPendingTasks.Size = new System.Drawing.Size(217, 304);
            this.listPendingTasks.TabIndex = 27;
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Rockwell", 14.25F);
            this.label1.Location = new System.Drawing.Point(482, 96);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(137, 27);
            this.label1.TabIndex = 36;
            this.label1.Text = "Completed";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Rockwell", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(257, 96);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(149, 27);
            this.label4.TabIndex = 35;
            this.label4.Text = "Things to do";
            // 
            // btnAddTask
            // 
            this.btnAddTask.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnAddTask.BackColor = System.Drawing.Color.Transparent;
            this.btnAddTask.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAddTask.FlatAppearance.BorderSize = 0;
            this.btnAddTask.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnAddTask.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnAddTask.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAddTask.Font = new System.Drawing.Font("Microsoft Tai Le", 14.25F);
            this.btnAddTask.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAddTask.ImageKey = "plus.png";
            this.btnAddTask.ImageList = this.ımageList1;
            this.btnAddTask.Location = new System.Drawing.Point(13, 317);
            this.btnAddTask.Margin = new System.Windows.Forms.Padding(4);
            this.btnAddTask.Name = "btnAddTask";
            this.btnAddTask.Size = new System.Drawing.Size(193, 49);
            this.btnAddTask.TabIndex = 33;
            this.btnAddTask.Text = " Add Task";
            this.btnAddTask.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnAddTask.UseVisualStyleBackColor = false;
            this.btnAddTask.Click += new System.EventHandler(this.btnAddTask_Click);
            // 
            // btnDeleteTask
            // 
            this.btnDeleteTask.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnDeleteTask.BackColor = System.Drawing.Color.Transparent;
            this.btnDeleteTask.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDeleteTask.FlatAppearance.BorderSize = 0;
            this.btnDeleteTask.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnDeleteTask.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnDeleteTask.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDeleteTask.Font = new System.Drawing.Font("Microsoft Tai Le", 14.25F);
            this.btnDeleteTask.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDeleteTask.ImageKey = "cancel.png";
            this.btnDeleteTask.ImageList = this.ımageList1;
            this.btnDeleteTask.Location = new System.Drawing.Point(13, 374);
            this.btnDeleteTask.Margin = new System.Windows.Forms.Padding(4);
            this.btnDeleteTask.Name = "btnDeleteTask";
            this.btnDeleteTask.Size = new System.Drawing.Size(218, 48);
            this.btnDeleteTask.TabIndex = 32;
            this.btnDeleteTask.Text = "Delete Task";
            this.btnDeleteTask.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDeleteTask.UseVisualStyleBackColor = false;
            this.btnDeleteTask.Click += new System.EventHandler(this.btnDeleteTask_Click);
            // 
            // btnUndoCompleted
            // 
            this.btnUndoCompleted.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnUndoCompleted.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnUndoCompleted.FlatAppearance.BorderSize = 0;
            this.btnUndoCompleted.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnUndoCompleted.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnUndoCompleted.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUndoCompleted.Font = new System.Drawing.Font("Microsoft Tai Le", 14.25F);
            this.btnUndoCompleted.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnUndoCompleted.ImageKey = "back-arrow.png";
            this.btnUndoCompleted.ImageList = this.ımageList1;
            this.btnUndoCompleted.Location = new System.Drawing.Point(541, 454);
            this.btnUndoCompleted.Margin = new System.Windows.Forms.Padding(4);
            this.btnUndoCompleted.Name = "btnUndoCompleted";
            this.btnUndoCompleted.Size = new System.Drawing.Size(163, 50);
            this.btnUndoCompleted.TabIndex = 30;
            this.btnUndoCompleted.Text = "Undo";
            this.btnUndoCompleted.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnUndoCompleted.UseVisualStyleBackColor = true;
            this.btnUndoCompleted.Click += new System.EventHandler(this.btnUndoCompleted_Click);
            // 
            // lblCountdown
            // 
            this.lblCountdown.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblCountdown.AutoSize = true;
            this.lblCountdown.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblCountdown.Location = new System.Drawing.Point(364, 305);
            this.lblCountdown.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCountdown.Name = "lblCountdown";
            this.lblCountdown.Size = new System.Drawing.Size(0, 39);
            this.lblCountdown.TabIndex = 43;
            // 
            // btnPauseTimer
            // 
            this.btnPauseTimer.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnPauseTimer.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.btnPauseTimer.Location = new System.Drawing.Point(392, 230);
            this.btnPauseTimer.Margin = new System.Windows.Forms.Padding(4);
            this.btnPauseTimer.Name = "btnPauseTimer";
            this.btnPauseTimer.Size = new System.Drawing.Size(115, 59);
            this.btnPauseTimer.TabIndex = 42;
            this.btnPauseTimer.Text = "Counter Stop";
            this.btnPauseTimer.UseVisualStyleBackColor = true;
            this.btnPauseTimer.Click += new System.EventHandler(this.btnPauseTimer_Click);
            // 
            // btnStartTimer
            // 
            this.btnStartTimer.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnStartTimer.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.btnStartTimer.Location = new System.Drawing.Point(147, 230);
            this.btnStartTimer.Margin = new System.Windows.Forms.Padding(4);
            this.btnStartTimer.Name = "btnStartTimer";
            this.btnStartTimer.Size = new System.Drawing.Size(115, 59);
            this.btnStartTimer.TabIndex = 41;
            this.btnStartTimer.Text = "Start Counter";
            this.btnStartTimer.UseVisualStyleBackColor = true;
            this.btnStartTimer.Click += new System.EventHandler(this.btnStartTimer_Click);
            // 
            // txtTimerInput
            // 
            this.txtTimerInput.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtTimerInput.Location = new System.Drawing.Point(270, 174);
            this.txtTimerInput.Margin = new System.Windows.Forms.Padding(4);
            this.txtTimerInput.Name = "txtTimerInput";
            this.txtTimerInput.Size = new System.Drawing.Size(236, 37);
            this.txtTimerInput.TabIndex = 40;
            this.txtTimerInput.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTimerInput_KeyPress);
            // 
            // chkSeconds
            // 
            this.chkSeconds.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.chkSeconds.AutoSize = true;
            this.chkSeconds.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.chkSeconds.Location = new System.Drawing.Point(394, 113);
            this.chkSeconds.Margin = new System.Windows.Forms.Padding(4);
            this.chkSeconds.Name = "chkSeconds";
            this.chkSeconds.Size = new System.Drawing.Size(87, 24);
            this.chkSeconds.TabIndex = 39;
            this.chkSeconds.Text = "Second";
            this.chkSeconds.UseVisualStyleBackColor = true;
            // 
            // chkMinutes
            // 
            this.chkMinutes.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.chkMinutes.AutoSize = true;
            this.chkMinutes.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.chkMinutes.Location = new System.Drawing.Point(392, 81);
            this.chkMinutes.Margin = new System.Windows.Forms.Padding(4);
            this.chkMinutes.Name = "chkMinutes";
            this.chkMinutes.Size = new System.Drawing.Size(81, 24);
            this.chkMinutes.TabIndex = 38;
            this.chkMinutes.Text = "Minute";
            this.chkMinutes.UseVisualStyleBackColor = true;
            // 
            // chkHours
            // 
            this.chkHours.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.chkHours.AutoSize = true;
            this.chkHours.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.chkHours.Location = new System.Drawing.Point(392, 49);
            this.chkHours.Margin = new System.Windows.Forms.Padding(4);
            this.chkHours.Name = "chkHours";
            this.chkHours.Size = new System.Drawing.Size(68, 24);
            this.chkHours.TabIndex = 37;
            this.chkHours.Text = "Hour";
            this.chkHours.UseVisualStyleBackColor = true;
            // 
            // timer2
            // 
            this.timer2.Interval = 1000;
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // btnResetTimer
            // 
            this.btnResetTimer.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnResetTimer.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.btnResetTimer.Location = new System.Drawing.Point(270, 230);
            this.btnResetTimer.Margin = new System.Windows.Forms.Padding(4);
            this.btnResetTimer.Name = "btnResetTimer";
            this.btnResetTimer.Size = new System.Drawing.Size(115, 59);
            this.btnResetTimer.TabIndex = 46;
            this.btnResetTimer.Text = "Reset Counter";
            this.btnResetTimer.UseVisualStyleBackColor = true;
            this.btnResetTimer.Click += new System.EventHandler(this.btnResetTimer_Click);
            // 
            // btnResumeTimer
            // 
            this.btnResumeTimer.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnResumeTimer.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.btnResumeTimer.Location = new System.Drawing.Point(515, 230);
            this.btnResumeTimer.Margin = new System.Windows.Forms.Padding(4);
            this.btnResumeTimer.Name = "btnResumeTimer";
            this.btnResumeTimer.Size = new System.Drawing.Size(115, 59);
            this.btnResumeTimer.TabIndex = 45;
            this.btnResumeTimer.Text = "Resume Counter";
            this.btnResumeTimer.UseVisualStyleBackColor = true;
            this.btnResumeTimer.Click += new System.EventHandler(this.btnResumeTimer_Click);
            // 
            // label7
            // 
            this.label7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.label7.Location = new System.Drawing.Point(193, 49);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(171, 20);
            this.label7.TabIndex = 44;
            this.label7.Text = "Select Duration Type:";
            // 
            // btnGenerateReport
            // 
            this.btnGenerateReport.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnGenerateReport.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.btnGenerateReport.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGenerateReport.ImageKey = "report.png";
            this.btnGenerateReport.ImageList = this.ımageList1;
            this.btnGenerateReport.Location = new System.Drawing.Point(1167, 763);
            this.btnGenerateReport.Margin = new System.Windows.Forms.Padding(4);
            this.btnGenerateReport.Name = "btnGenerateReport";
            this.btnGenerateReport.Size = new System.Drawing.Size(236, 90);
            this.btnGenerateReport.TabIndex = 48;
            this.btnGenerateReport.Text = "Get Report of the Day";
            this.btnGenerateReport.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnGenerateReport.UseVisualStyleBackColor = true;
            this.btnGenerateReport.Click += new System.EventHandler(this.btnGenerateReport_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.groupBox1.Controls.Add(this.btnResumeTimer);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.lblCountdown);
            this.groupBox1.Controls.Add(this.btnResetTimer);
            this.groupBox1.Controls.Add(this.btnPauseTimer);
            this.groupBox1.Controls.Add(this.chkHours);
            this.groupBox1.Controls.Add(this.btnStartTimer);
            this.groupBox1.Controls.Add(this.chkMinutes);
            this.groupBox1.Controls.Add(this.txtTimerInput);
            this.groupBox1.Controls.Add(this.chkSeconds);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox1.Location = new System.Drawing.Point(82, 512);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(755, 375);
            this.groupBox1.TabIndex = 49;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Check Time";
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.groupBox2.Controls.Add(this.listCompletedTasks);
            this.groupBox2.Controls.Add(this.btnUndoCompleted);
            this.groupBox2.Controls.Add(this.btnDeleteTask);
            this.groupBox2.Controls.Add(this.txtTaskInput);
            this.groupBox2.Controls.Add(this.btnAddTask);
            this.groupBox2.Controls.Add(this.btnMarkCompleted);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.listPendingTasks);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox2.Location = new System.Drawing.Point(865, 42);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox2.Size = new System.Drawing.Size(791, 704);
            this.groupBox2.TabIndex = 50;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Todo List";
            // 
            // groupBox3
            // 
            this.groupBox3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.groupBox3.Controls.Add(this.monthCalendar1);
            this.groupBox3.Controls.Add(this.btnRemoveFromCalendar);
            this.groupBox3.Controls.Add(this.btnAddToCalendar);
            this.groupBox3.Controls.Add(this.calendarList);
            this.groupBox3.Controls.Add(this.lblDate);
            this.groupBox3.Controls.Add(this.lblSelectDate);
            this.groupBox3.Controls.Add(this.txtTaskDescription);
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox3.Location = new System.Drawing.Point(68, 30);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox3.Size = new System.Drawing.Size(789, 474);
            this.groupBox3.TabIndex = 51;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "First Planning";
            // 
            // allForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1688, 900);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnGenerateReport);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "allForm";
            this.Text = "allForm";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.allForm_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);

        }

        private void label1_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        private void sure_KeyPress(object sender, KeyPressEventArgs e)
        {
            throw new NotImplementedException();
        }

        #endregion
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label lblDate;
        private System.Windows.Forms.MonthCalendar monthCalendar1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtTaskDescription;
        private System.Windows.Forms.Label lblSelectDate;
        private System.Windows.Forms.ListBox calendarList;
        private System.Windows.Forms.Button btnAddToCalendar;
        private System.Windows.Forms.Button btnRemoveFromCalendar;
        private System.Windows.Forms.ImageList ımageList1;
        private System.Windows.Forms.TextBox txtTaskInput;
        private System.Windows.Forms.Button btnMarkCompleted;
        private System.Windows.Forms.ListBox listCompletedTasks;
        private System.Windows.Forms.ListBox listPendingTasks;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnAddTask;
        private System.Windows.Forms.Button btnDeleteTask;
        private System.Windows.Forms.Button btnUndoCompleted;
        private System.Windows.Forms.Label lblCountdown;
        private System.Windows.Forms.Button btnPauseTimer;
        private System.Windows.Forms.Button btnStartTimer;
        private System.Windows.Forms.TextBox txtTimerInput;
        private System.Windows.Forms.CheckBox chkSeconds;
        private System.Windows.Forms.CheckBox chkMinutes;
        private System.Windows.Forms.CheckBox chkHours;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.Button btnResetTimer;
        private System.Windows.Forms.Button btnResumeTimer;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btnGenerateReport;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
    }
}

