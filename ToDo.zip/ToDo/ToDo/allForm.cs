﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace ToDo
{
    public partial class allForm : Form
    {
        // سلسلة الاتصال بقاعدة البيانات
        private string connectionString = @"Data Source=.\SQLEXPRESS;Initial Catalog=TaskManagerDB;Integrated Security=True";

        public allForm()
        {
            InitializeComponent();
        }

        // ==========================================
        // أحداث التحميل والإعدادات الأولية
        // ==========================================

        private void allForm_Load(object sender, EventArgs e)
        {
            LoadCalendarEvents();  // تحميل الأحداث عند بداية تحميل النموذج
            LoadTasks();  // تحميل المهام
            timer2.Start();  // بدء المؤقت لعرض التاريخ والوقت الحالي

            // إضافة تلميحات للأزرار
            ToolTip toolTip = new ToolTip();
            toolTip.SetToolTip(btnAddTask, "Add Task");
            toolTip.SetToolTip(btnDeleteTask, "Delete Selected Task");
            toolTip.SetToolTip(btnMarkCompleted, "Move Selected Task to Completed List");
            toolTip.SetToolTip(btnUndoCompleted, "Move Selected Task Back from Completed List");
        }

        // ==========================================
        // دوال تحميل البيانات
        // ==========================================

        // دالة لتحميل المهام من قاعدة البيانات
        private void LoadTasks()
        {
            listPendingTasks.Items.Clear();  // مسح قائمة المهام المعلقة
            listCompletedTasks.Items.Clear();  // مسح قائمة المهام المكتملة

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = "SELECT Id, TaskDescription, IsCompleted FROM TaskList";
                SqlCommand cmd = new SqlCommand(query, conn);
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    string task = reader["TaskDescription"].ToString();
                    bool isCompleted = Convert.ToBoolean(reader["IsCompleted"]);

                    // إضافة المهمة إلى القائمة المناسبة بناءً على حالة الإكمال
                    if (isCompleted)
                    {
                        listCompletedTasks.Items.Add(task);
                    }
                    else
                    {
                        listPendingTasks.Items.Add(task);
                    }
                }
            }
        }

        // دالة لتحميل الأحداث من قاعدة البيانات
        private void LoadCalendarEvents()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    string query = "SELECT EventDate, EventDescription FROM Calendar ORDER BY EventDate";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    conn.Open();
                    SqlDataReader reader = cmd.ExecuteReader();

                    calendarList.Items.Clear();
                    while (reader.Read())
                    {
                        string eventDate = reader["EventDate"].ToString();
                        string eventDescription = reader["EventDescription"].ToString();
                        calendarList.Items.Add(eventDate + " - " + eventDescription);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // ==========================================
        // دوال إدارة المهام
        // ==========================================

        // حدث النقر على زر إضافة مهمة
        private void btnAddTask_Click(object sender, EventArgs e)
        {
            string taskDescription = txtTaskInput.Text.Trim();

            if (!string.IsNullOrEmpty(taskDescription))
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    string query = "INSERT INTO TaskList (TaskDescription, IsCompleted) VALUES (@TaskDescription, 0)";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@TaskDescription", taskDescription);
                    cmd.ExecuteNonQuery();
                }

                txtTaskInput.Clear();
                LoadTasks();
            }
            else
            {
                MessageBox.Show("No task found to add!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        // حدث النقر على زر حذف مهمة
        private void btnDeleteTask_Click(object sender, EventArgs e)
        {
            string selectedTask = null;

            if (listPendingTasks.SelectedItem != null)
            {
                selectedTask = listPendingTasks.SelectedItem.ToString();
            }
            else if (listCompletedTasks.SelectedItem != null)
            {
                selectedTask = listCompletedTasks.SelectedItem.ToString();
            }

            if (!string.IsNullOrEmpty(selectedTask))
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    string query = "DELETE FROM TaskList WHERE TaskDescription = @TaskDescription";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@TaskDescription", selectedTask);
                    cmd.ExecuteNonQuery();
                }

                LoadTasks();
            }
            else
            {
                MessageBox.Show("No task found to delete!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        // حدث النقر على زر تعيين مهمة كمكتملة
        private void btnMarkCompleted_Click(object sender, EventArgs e)
        {
            foreach (var selectedTask in listPendingTasks.SelectedItems)
            {
                UpdateTaskCompletion(selectedTask.ToString(), true);
            }

            LoadTasks();
        }

        // حدث النقر على زر إعادة مهمة إلى قائمة المهام المعلقة
        private void btnUndoCompleted_Click(object sender, EventArgs e)
        {
            foreach (var selectedTask in listCompletedTasks.SelectedItems)
            {
                UpdateTaskCompletion(selectedTask.ToString(), false);
            }

            LoadTasks();
        }

        // دالة لتحديث حالة إكمال المهمة
        private void UpdateTaskCompletion(string taskDescription, bool isCompleted)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = "UPDATE TaskList SET IsCompleted = @IsCompleted WHERE TaskDescription = @TaskDescription";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@IsCompleted", isCompleted);
                cmd.Parameters.AddWithValue("@TaskDescription", taskDescription);
                cmd.ExecuteNonQuery();
            }
        }

        // ==========================================
        // دوال إدارة الأحداث
        // ==========================================

        // حدث النقر على زر إضافة حدث إلى التقويم
        private void btnAddToCalendar_Click(object sender, EventArgs e)
        {
            if (lblSelectDate.Text != "Select Date..." && !string.IsNullOrWhiteSpace(txtTaskDescription.Text))
            {
                DateTime eventDate = DateTime.Parse(lblSelectDate.Text);
                string eventDescription = txtTaskDescription.Text;
                AddEventToCalendar(eventDate, eventDescription);

                txtTaskDescription.Clear();
                lblSelectDate.Text = "Select Date...";
            }
            else
            {
                MessageBox.Show("Fill in the Date and Task Description!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        // دالة لإضافة حدث إلى قاعدة البيانات
        private void AddEventToCalendar(DateTime eventDate, string eventDescription)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    string query = "INSERT INTO Calendar (EventDate, EventDescription) VALUES (@EventDate, @EventDescription)";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@EventDate", eventDate);
                    cmd.Parameters.AddWithValue("@EventDescription", eventDescription);

                    conn.Open();
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Event added successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    LoadCalendarEvents();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // حدث النقر على زر حذف حدث من التقويم
        private void btnRemoveEvent_Click(object sender, EventArgs e)
        {
            if (calendarList.SelectedIndex != -1)
            {
                string selectedEvent = calendarList.SelectedItem.ToString();
                string[] eventDetails = selectedEvent.Split(new string[] { " - " }, StringSplitOptions.None);
                string eventDate = eventDetails[0];
                string eventDescription = eventDetails[1];

                DeleteEventFromCalendar(eventDate, eventDescription);
                LoadCalendarEvents();
            }
            else
            {
                MessageBox.Show("Select an event to delete", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        // دالة لحذف حدث من قاعدة البيانات
        private void DeleteEventFromCalendar(string eventDate, string eventDescription)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    string query = "DELETE FROM Calendar WHERE EventDate = @EventDate AND EventDescription = @EventDescription";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@EventDate", eventDate);
                    cmd.Parameters.AddWithValue("@EventDescription", eventDescription);

                    conn.Open();
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Event deleted successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // دالة لإزالة حدث من التقويم
        private void RemoveEventFromCalendar(DateTime eventDate, string eventDescription)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    string query = "DELETE FROM Calendar WHERE EventDate = @EventDate AND EventDescription = @EventDescription";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@EventDate", eventDate);
                    cmd.Parameters.AddWithValue("@EventDescription", eventDescription);

                    conn.Open();
                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // حدث تغيير التاريخ في التقويم
        private void monthCalendar1_DateChanged(object sender, DateRangeEventArgs e)
        {
            lblSelectDate.Text = monthCalendar1.SelectionStart.ToLongDateString();
        }

        // حدث النقر على زر إزالة حدث من التقويم
        private void btnRemoveFromCalendar_Click(object sender, EventArgs e)
        {
            if (calendarList.SelectedIndex != -1)
            {
                string selectedEvent = calendarList.SelectedItem.ToString();
                string[] eventDetails = selectedEvent.Split(new string[] { " - " }, StringSplitOptions.None);
                DateTime eventDate = DateTime.Parse(eventDetails[0]);
                string eventDescription = eventDetails[1];

                calendarList.Items.RemoveAt(calendarList.SelectedIndex);
                RemoveEventFromCalendar(eventDate, eventDescription);
            }
            else
            {
                MessageBox.Show("Select an event to delete!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        // ==========================================
        // دوال المؤقت (Timer)
        // ==========================================

        // حدث المؤقت لعرض العد التنازلي
        private void timer1_Tick(object sender, EventArgs e)
        {
            lblCountdown.Text = ((int.Parse(lblCountdown.Text) - 1).ToString());
            if (int.Parse(lblCountdown.Text) < 10)
            {
                lblCountdown.ForeColor = Color.Red;
            }
            else
            {
                lblCountdown.ForeColor = Color.Black;
            }
            if (int.Parse(lblCountdown.Text) < 1)
            {
                timer1.Stop();
                MessageBox.Show("Time's up", "Info");
                txtTimerInput.Enabled = true;
                txtTimerInput.Text = "";
                chkHours.Enabled = true;
                chkMinutes.Enabled = true;
                chkSeconds.Enabled = true;
                lblCountdown.Text = "";
                chkHours.Checked = false;
                chkMinutes.Checked = false;
                chkSeconds.Checked = false;
            }
        }



        // حدث المؤقت لعرض التاريخ والوقت الحالي
        private void timer2_Tick(object sender, EventArgs e)
        {
            lblSelectDate.Text = DateTime.Now.ToString("dd/MM/yyyy" + "\n" + "hh:mm:ss tt");
        }



        // حدث النقر على زر بدء المؤقت
        private void btnStartTimer_Click(object sender, EventArgs e)
        {
            lblCountdown.ForeColor = Color.Black;
            try
            {
                if (chkHours.Checked || chkMinutes.Checked || chkSeconds.Checked)
                {
                    if (txtTimerInput.Text != "")
                    {
                        if (chkHours.Checked)
                        {
                            lblCountdown.Text = ((int.Parse(txtTimerInput.Text)) * 60 * 60).ToString();
                        }
                        else if (chkMinutes.Checked)
                        {
                            lblCountdown.Text = ((int.Parse(txtTimerInput.Text)) * 60).ToString();
                        }
                        else if (chkSeconds.Checked)
                        {
                            lblCountdown.Text = ((int.Parse(txtTimerInput.Text))).ToString();
                        }
                        timer1.Start();
                        txtTimerInput.Clear();
                        txtTimerInput.Enabled = false;
                        txtTimerInput.Text = "Timer Running!";
                        chkHours.Enabled = false;
                        chkMinutes.Enabled = false;
                        chkSeconds.Enabled = false;

                        btnStartTimer.Enabled = false;
                        btnResetTimer.Enabled = true;
                        btnResumeTimer.Enabled = true;
                        btnPauseTimer.Enabled = true;
                    }
                    else
                    {
                        MessageBox.Show("Enter the time.", "Error");
                    }
                }
                else
                {
                    MessageBox.Show("Select the time type.", "Error");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error");
            }
        }

        // حدث النقر على زر إعادة تعيين المؤقت
        private void btnResetTimer_Click(object sender, EventArgs e)
        {
            timer1.Stop();
            txtTimerInput.Enabled = true;
            txtTimerInput.Text = "";
            chkHours.Enabled = true;
            chkMinutes.Enabled = true;
            chkSeconds.Enabled = true;
            lblCountdown.Text = "";
            chkHours.Checked = false;
            chkMinutes.Checked = false;
            chkSeconds.Checked = false;
            btnStartTimer.Enabled = true;
            btnResetTimer.Enabled = false;
            btnResumeTimer.Enabled = false;
            btnResumeTimer.Enabled = false;
        }

        // حدث النقر على زر إيقاف المؤقت مؤقتًا
        private void btnPauseTimer_Click(object sender, EventArgs e)
        {
            timer1.Stop();
            txtTimerInput.Text = "Timer Paused!";
            if (txtTimerInput.Text == null)
                txtTimerInput.Enabled = false;
            chkHours.Enabled = false;
            chkMinutes.Enabled = false;
            chkSeconds.Enabled = false;
        }

        // حدث النقر على زر استئناف المؤقت
        private void btnResumeTimer_Click(object sender, EventArgs e)
        {
            timer1.Start();
            txtTimerInput.Enabled = false;
            txtTimerInput.Text = "Timer Running!";
            chkHours.Enabled = false;
            chkMinutes.Enabled = false;
            chkSeconds.Enabled = false;
        }

        // حدث التحقق من إدخال الأرقام فقط في حقل المؤقت
        private void txtTimerInput_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        // ==========================================
        // دوال أخرى
        // ==========================================

        // حدث النقر على زر إنشاء تقرير
        private void btnGenerateReport_Click(object sender, EventArgs e)
        {
            string path = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
            string fileName = path + "/ToDo_Report.txt";
            using (StreamWriter sw = new StreamWriter(fileName))
            {
                sw.WriteLine("Calendar Plan \n");
                foreach (var item in calendarList.Items)
                {
                    sw.WriteLine(Convert.ToString(item));
                }
                sw.WriteLine("\n");
                sw.WriteLine("Pending Tasks \n");
                foreach (var item in listPendingTasks.Items)
                {
                    sw.WriteLine(Convert.ToString(item));
                }
                sw.WriteLine("\n");
                sw.WriteLine("Completed Tasks \n");
                foreach (var item in listCompletedTasks.Items)
                {
                    sw.WriteLine(Convert.ToString(item));
                }
                sw.WriteLine("\n");
              
            }

            MessageBox.Show("Your report has been saved to the desktop!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        // حدث النقر على تسمية التاريخ
        private void lblSelectDate_Click(object sender, EventArgs e)
        {
        }
    }
}